import { Component, OnInit } from '@angular/core';
import { LabourserviceService } from '../../service/labourservice.service';
import { Router } from '@angular/router';
import { Labour } from '../../model/labour';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-labourlist',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './labourlist.component.html',
  styleUrls: ['./labourlist.component.css']
})
export class LabourlistComponent implements OnInit {
  labours: Labour[] = [];

  constructor(private labourService: LabourserviceService, private router: Router) {}

  ngOnInit(): void {
    this.getLabours();
  }

  getLabours(): void {
    this.labourService.getAllLabours().subscribe(data => {
      console.log("Labour data received:", data);  // 👈 Debug
      this.labours = data;
    }, error => {
      console.error("Error while fetching labours:", error);
    });
  }

  addLabour(): void {
    this.router.navigate(['/labourform']);
  }

  editLabour(id: number): void {
    this.router.navigate(['/edit', id]);
  }

  deleteLabour(id: number): void {
    this.labourService.deleteLabour(id).subscribe(() => {
      this.getLabours();
    });
  }
}
